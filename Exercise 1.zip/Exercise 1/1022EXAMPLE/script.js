window.document.write("Hannah Kang");
a=5; // 변수 a에 값 1을 저장
x=++a; // 증가 연산자 (++)가 변수 a의 앞에 작성되어 있으므로 
        // 변수 a값에 1을 더한 값을 변수 x에 저장
        // x>>2, a>>2
window.document.write(x+" "); // 가 = 2
//변수 x의 값을 HTML 문서에 출력
window.document.write(a+" "); // 다 == 3
a=5;
x=a++; // 증가연산자(++) 변수 a의 뒤에 작성되어 있으므로
       // 변수 x에 변수 a의 값을 저장하고, 변수 a의 값을 1 더함
       // x >> 2, a >> 3
window.document.write(x+" "); // 나 = 2
//변수 x의 값을 HTML 문서에 출력
window.document.write(a+" "); // 다 == 3
//변수 a의 값을 HTML 문서에 출력
d="ab\ncd"; 
window.document.write(d);