function myAlert(msg){
	alert(msg);
}